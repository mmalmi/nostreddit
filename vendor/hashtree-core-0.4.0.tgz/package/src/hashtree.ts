import { type EncryptionMode } from './encryption.js';
/**
 * HashTree - Unified merkle tree operations
 *
 * Single class for creating, reading, and editing content-addressed merkle trees.
 *
 * All files are encrypted by default using CHK (Content Hash Key) encryption.
 * Pass `{ unencrypted: true }` to write plaintext instead. Reads use the CID's key
 * when present. Tree edits return a new root and preserve the previous tree.
 */

import { Store, Hash, CID, TreeNode, LinkType, toHex, cid } from './types.js';
import { tryDecodeTreeNode } from './codec.js';
import { StreamWriter } from './streaming.js';
import * as streaming from './streaming.js';
export { StreamWriter } from './streaming.js';
export { verifyTree } from './verify.js';
import * as create from './tree/create.js';
import * as read from './tree/read.js';
import * as edit from './tree/edit.js';
import {
  putFileEncrypted,
  readFileEncrypted,
  readFileEncryptedStream,
  readFileEncryptedRange,
  putDirectoryEncrypted,
  listDirectoryEncrypted,
  getTreeNodeEncrypted,
  decryptRootNodeOrBlob,
  type EncryptedDirEntry,
} from './encrypted.js';
import * as editEncrypted from './tree/editEncrypted.js';
import * as writeAtOps from './tree/writeAt.js';

/** Default chunk size: 2MB (optimized for blossom uploads) */
export const DEFAULT_CHUNK_SIZE = 2 * 1024 * 1024;
/** Default maximum links per tree node */
export const DEFAULT_MAX_LINKS = 174;

export interface HashTreeConfig {
  /** Backend for content-addressed blocks. Writes do not imply remote replication. */
  store: Store;
  /** Maximum plaintext bytes per file chunk. Defaults to 2 MiB. */
  chunkSize?: number;
  /** Maximum links per tree node. Defaults to 174. */
  maxLinks?: number;
  /** Encryption suite for new objects. Defaults to versioned CHK. */
  encryptionMode?: EncryptionMode;
}

export interface TreeEntry {
  name: string;
  cid: CID;
  size: number;
  type: LinkType;
  meta?: Record<string, unknown>;
}

export interface DirEntry {
  /** Child name within this directory. */
  name: string;
  /** Complete child identifier, including its decryption key when encrypted. */
  cid: CID;
  /** Plaintext content size in bytes. */
  size: number;
  /** Use File for putFile results and Dir for child directories. */
  type: LinkType;
  /** Optional application metadata stored with the entry. */
  meta?: Record<string, unknown>;
}

export interface ReadOptions {
  /** Maximum plaintext bytes to return before throwing */
  maxBytes?: number;
}

/**
 * HashTree - create, read, and edit merkle trees
 */
export class HashTree {
  private store: Store;
  private chunkSize: number;
  private maxLinks: number;
  private encryptionMode: EncryptionMode;

  constructor(config: HashTreeConfig) {
    this.store = config.store;
    this.encryptionMode = config.encryptionMode ?? 'chk-v1';
    this.chunkSize = config.chunkSize ?? DEFAULT_CHUNK_SIZE;
    this.maxLinks = config.maxLinks ?? DEFAULT_MAX_LINKS;
    if (!Number.isInteger(this.maxLinks) || this.maxLinks < 1) {
      throw new Error(`Invalid maxLinks: ${config.maxLinks}`);
    }
  }

  private get config(): create.CreateConfig {
    return { store: this.store, chunkSize: this.chunkSize, maxLinks: this.maxLinks, encryptionMode: this.encryptionMode };
  }

  // Create (encrypted by default)

  async putBlob(data: Uint8Array): Promise<Hash> {
    return create.putBlob(this.store, data);
  }

  /**
   * Chunk and store a file, encrypted with a content-derived key by default.
   * @param data - File data to store
   * @param options - { unencrypted?: boolean } - if true, store without encryption
   * @returns The complete CID and plaintext byte length. Retain the CID's key.
   */
  async putFile(
    data: Uint8Array,
    options?: { unencrypted?: boolean }
  ): Promise<{ cid: CID; size: number }> {
    if (options?.unencrypted) {
      const result = await create.putFile(this.config, data);
      return { cid: { hash: result.hash }, size: result.size };
    }
    const result = await putFileEncrypted(this.config, data);
    return { cid: cid(result.hash, result.key), size: result.size };
  }

  /**
   * Store a directory of child CIDs and metadata.
   *
   * Directory encryption is independent of child encryption. An unencrypted
   * directory exposes any child keys included in its entries.
   * @param entries - Directory entries
   * @param options - { unencrypted?: boolean } - if true, store without encryption
   * @returns The directory CID and sum of child plaintext sizes.
   */
  async putDirectory(
    entries: DirEntry[],
    options?: { unencrypted?: boolean }
  ): Promise<{ cid: CID; size: number }> {
    const size = entries.reduce((sum, e) => sum + (e.size ?? 0), 0);
    if (options?.unencrypted) {
      const dirEntries: create.DirEntry[] = entries.map(e => ({
        name: e.name,
        cid: e.cid,
        size: e.size,
        type: e.type ?? LinkType.Blob,
        meta: e.meta,
      }));
      const hash = await create.putDirectory(this.config, dirEntries);
      return { cid: { hash }, size };
    }
    // Encrypted by default
    const encryptedEntries: EncryptedDirEntry[] = entries.map(e => ({
      name: e.name,
      hash: e.cid.hash,
      size: e.size,
      key: e.cid.key,
      type: e.type ?? LinkType.Blob,
      meta: e.meta,
    }));
    const result = await putDirectoryEncrypted(this.config, encryptedEntries);
    return { cid: cid(result.hash, result.key), size };
  }

  // Read

  async getBlob(hash: Hash): Promise<Uint8Array | null> {
    return read.getBlob(this.store, hash);
  }

  /**
   * Get a tree node
   */
  async getTreeNode(id: CID): Promise<TreeNode | null> {
    if (id.key) {
      return getTreeNodeEncrypted(this.store, id.hash, id.key);
    }
    return read.getTreeNode(this.store, id.hash);
  }

  async getType(id: CID): Promise<LinkType> {
    if (!id?.hash) return LinkType.Blob;
    return read.getType(this.store, id.hash);
  }

  async isDirectory(id: CID): Promise<boolean> {
    if (!id?.hash) return false;
    // For encrypted directories, we need to decrypt to check the node type
    if (id.key) {
      try {
        // Try to get the tree node (will decrypt and validate)
        const node = await getTreeNodeEncrypted(this.store, id.hash, id.key);
        if (!node) return false;
        return node.type === LinkType.Dir || node.type === LinkType.Fanout;
      } catch {
        return false;
      }
    }
    return read.isDirectory(this.store, id.hash);
  }

  /**
   * Assemble and decrypt a file using its complete CID.
   *
   * @returns Plaintext bytes, or null when required content is unavailable.
   * @throws If the configured byte limit is exceeded or a storage/decryption
   * operation fails. A local miss does not prove absence from the network.
   */
  async readFile(id: CID, options: ReadOptions = {}): Promise<Uint8Array | null> {
    return this.get(id, options);
  }

  /**
   * Get content by CID (alias of readFile)
   */
  async get(id: CID, options: ReadOptions = {}): Promise<Uint8Array | null> {
    if (id.key) {
      return readFileEncrypted(this.store, id.hash, id.key, options);
    }
    return read.readFile(this.store, id.hash, options);
  }

  /**
   * Stream a file
   * @param id - CID of the file
   * @param options - { offset?: number, prefetch?: number }
   */
  async *readFileStream(
    id: CID,
    options: { offset?: number; prefetch?: number } = {}
  ): AsyncGenerator<Uint8Array> {
    if (id.key) {
      yield* readFileEncryptedStream(this.store, id.hash, id.key, options);
    } else {
      yield* read.readFileStream(this.store, id.hash, options);
    }
  }

  /**
   * Read plaintext bytes from inclusive `start` to exclusive `end`.
   * Omit `end` to read through the end of the file.
   */
  async readFileRange(id: CID, start: number, end?: number): Promise<Uint8Array | null> {
    if (id.key) {
      return readFileEncryptedRange(this.store, id.hash, id.key, start, end);
    }
    return read.readFileRange(this.store, id.hash, start, end);
  }

  /**
   * List directory entries.
   *
   * Waits for the directory block to load. Pass `signal` to bound the wait —
   * otherwise the call stays open until the data is available.
   */
  async listDirectory(id: CID, signal?: AbortSignal): Promise<TreeEntry[]> {
    if (id.key) {
      const entries = await listDirectoryEncrypted(this.store, id.hash, id.key, signal);
      return entries.map(e => ({
        name: e.name,
        cid: cid(e.hash, e.key),
        size: e.size,
        type: e.type ?? LinkType.Blob,
        meta: e.meta,
      }));
    }
    const entries = await read.listDirectory(this.store, id.hash, signal);
    return entries.map(e => ({
      name: e.name,
      cid: e.cid,
      size: e.size,
      type: e.type,
      meta: e.meta,
    }));
  }

  /**
   * Resolve a path to get the entry's CID.
   *
   * Waits for each directory block in the path to load. Returns null only
   * when an entry is missing from a successfully-loaded directory listing —
   * never because of a transient sync delay. Pass `signal` to bound the wait.
   *
   * @param root - Root CID of the tree
   * @param path - Path to resolve (string like 'a/b/file.txt' or array like ['a', 'b', 'file.txt'])
   * @param signal - Optional AbortSignal to bound the wait
   * @returns { cid, type } or null if not found in the resolved directory
   */
  async resolvePath(
    root: CID,
    path: string | string[],
    signal?: AbortSignal
  ): Promise<{ cid: CID; type: LinkType } | null> {
    const parts = Array.isArray(path)
      ? path
      : path.split('/').filter(p => p.length > 0);

    let current = root;
    let entryType: LinkType = LinkType.Dir;

    for (const segment of parts) {
      const entries = await this.listDirectory(current, signal);
      const entry = entries.find(e => e.name === segment);
      if (!entry) {
        return null;
      }

      current = entry.cid;
      entryType = entry.type;
    }

    return { cid: current, type: entryType };
  }

  async getSize(hash: Hash): Promise<number> {
    return read.getSize(this.store, hash);
  }

  async *walk(
    hash: Hash,
    path: string = ''
  ): AsyncGenerator<{ path: string; hash: Hash; type: LinkType; size?: number }> {
    yield* read.walk(this.store, hash, path);
  }

  /**
   * Walk entire tree and return all entries as an array
   * More convenient than the async generator for most use cases
   * @param id - Root CID of the tree
   * @param options.includeData - If true, include file data in results
   * @param options.filesOnly - If true, only return files (not directories)
   */
  async walkTree(
    id: CID,
    options?: { includeData?: boolean; filesOnly?: boolean }
  ): Promise<Array<{ path: string; cid: CID; type: LinkType; size: number; data?: Uint8Array }>> {
    const results: Array<{ path: string; cid: CID; type: LinkType; size: number; data?: Uint8Array }> = [];

    const walkRecursive = async (currentCid: CID, currentPath: string): Promise<void> => {
      const isDir = await this.isDirectory(currentCid);

      if (isDir) {
        if (!options?.filesOnly) {
          const entries = await this.listDirectory(currentCid);
          const dirSize = entries.reduce((sum, e) => sum + e.size, 0);
          results.push({ path: currentPath, cid: currentCid, type: LinkType.Dir, size: dirSize });
        }

        const entries = await this.listDirectory(currentCid);
        for (const entry of entries) {
          const childPath = currentPath ? `${currentPath}/${entry.name}` : entry.name;
          await walkRecursive(entry.cid, childPath);
        }
      } else {
        // File or blob
        const type = await this.getType(currentCid);
        const size = await this.getSize(currentCid.hash);
        const result: { path: string; cid: CID; type: LinkType; size: number; data?: Uint8Array } = {
          path: currentPath,
          cid: currentCid,
          type,
          size,
        };

        if (options?.includeData) {
          const data = await this.readFile(currentCid);
          if (data) result.data = data;
        }

        results.push(result);
      }
    };

    await walkRecursive(id, '');
    return results;
  }

  /**
   * Iterate over all raw blocks in a merkle tree
   * Yields each block's hash and data, traversing encrypted nodes correctly
   * Useful for syncing to remote stores (e.g., Blossom push)
   * Throws if any referenced block is missing, so partial trees cannot look complete.
   */
  async *walkBlocks(id: CID): AsyncGenerator<{ hash: Hash; data: Uint8Array }> {
    const visited = new Set<string>();

    const traverse = async function* (
      store: Store,
      hash: Hash,
      key?: Uint8Array
    ): AsyncGenerator<{ hash: Hash; data: Uint8Array }> {
      const hex = toHex(hash);
      if (visited.has(hex)) return;
      visited.add(hex);

      const data = await store.get(hash);
      if (!data) throw new Error(`Missing block: ${hex}`);

      yield { hash, data };

      const node = tryDecodeTreeNode(key ? await decryptRootNodeOrBlob(data, key) : data);
      if (node) {
        for (const link of node.links) {
          yield* traverse(store, link.hash, link.key);
        }
      }
    };

    yield* traverse(this.store, id.hash, id.key);
  }

  /**
   * Pull (fetch) all chunks for a tree recursively
   * Triggers remote-store fetches for any missing chunks.
   * Uses parallel fetching within each tree level for better performance
   * @returns { cid, chunks, bytes } - The CID and stats about what was pulled
   */
  async pull(id: CID): Promise<{ cid: CID; chunks: number; bytes: number }> {
    const visited = new Set<string>();
    let chunks = 0;
    let bytes = 0;

    const fetch = async (hash: Hash, key?: Uint8Array): Promise<void> => {
      const hex = toHex(hash);
      if (visited.has(hex)) return;
      visited.add(hex);

      // Fetch the chunk from the configured store chain when it is not local.
      const data = await this.store.get(hash);
      if (!data) {
        return;
      }

      chunks++;
      bytes += data.length;

      // If there's an encryption key, try to decrypt and check if it's a tree node
      // For encrypted data, we can't use isTreeNode on the raw bytes
      if (key) {
        const decrypted = await getTreeNodeEncrypted(this.store, hash, key);
        if (decrypted) {
          // It's an encrypted tree node - fetch all children in parallel
          await Promise.all(decrypted.links.map(link => fetch(link.hash, link.key)));
        }
        // If decryption failed or not a tree node, it's a blob (already fetched)
      } else {
        // Unencrypted data - check directly
        const node = tryDecodeTreeNode(data);
        if (node) {
          // Fetch all children in parallel
          await Promise.all(node.links.map(link => fetch(link.hash, link.key)));
        }
        // If not a tree node, it's a blob (already fetched)
      }
    };

    await fetch(id.hash, id.key);
    return { cid: id, chunks, bytes };
  }

  /**
   * Push all chunks for a tree to a target store
   * Useful for syncing to remote stores (e.g., Blossom servers)
   * @param id - CID of the tree to push
   * @param targetStore - Store to push blocks to (must support put())
   * @param options - callbacks for progress and per-block status
   * @returns { cid, pushed, skipped, failed, bytes, errors } - The CID and detailed stats
   */
  async push(
    id: CID,
    targetStore: Store,
    options?: {
      onProgress?: (current: number, total: number) => void;
      onBlock?: (hash: Hash, status: 'success' | 'skipped' | 'error', error?: Error) => void;
      /** Number of parallel uploads (default: 4) */
      concurrency?: number;
      /** AbortSignal to cancel the push */
      signal?: AbortSignal;
    }
  ): Promise<{
    cid: CID;
    pushed: number;
    skipped: number;
    failed: number;
    bytes: number;
    errors: Array<{ hash: Hash; error: Error }>;
    cancelled: boolean;
  }> {
    // First pull to ensure all blocks are available locally
    const pullStats = await this.pull(id);

    // Check if already aborted
    if (options?.signal?.aborted) {
      return { cid: id, pushed: 0, skipped: 0, failed: 0, bytes: 0, errors: [], cancelled: true };
    }

    let pushed = 0;
    let skipped = 0;
    let failed = 0;
    let bytes = 0;
    let completed = 0;
    // Keep progress total stable: pull() already traversed and counted unique blocks.
    const discovered = pullStats.chunks;
    let walkDone = false;
    const errors: Array<{ hash: Hash; error: Error }> = [];

    const concurrency = options?.concurrency ?? 4;

    // Bounded queue for producer-consumer pattern
    const queue: Array<{ hash: Hash; data: Uint8Array }> = [];
    const maxQueueSize = concurrency * 2;
    let queueResolve: (() => void) | null = null;
    let consumerResolve: (() => void) | null = null;

    // Process a single block
    const processBlock = async (block: { hash: Hash; data: Uint8Array }) => {
      if (options?.signal?.aborted) return;

      const { hash, data } = block;
      try {
        const isNew = await targetStore.put(hash, data);
        if (isNew === false) {
          skipped++;
          options?.onBlock?.(hash, 'skipped');
        } else {
          pushed++;
          bytes += data.length;
          options?.onBlock?.(hash, 'success');
        }
      } catch (e) {
        failed++;
        const error = e instanceof Error ? e : new Error(String(e));
        errors.push({ hash, error });
        options?.onBlock?.(hash, 'error', error);
      }
      completed++;
      // Report progress: completed / discovered (stable total from pull()).
      options?.onProgress?.(completed, discovered);
    };

    // Consumer: pull from queue and process
    const runConsumer = async () => {
      const active: Promise<void>[] = [];

      while (!walkDone || queue.length > 0 || active.length > 0) {
        if (options?.signal?.aborted) break;

        // Start new tasks from queue
        while (active.length < concurrency && queue.length > 0) {
          const block = queue.shift()!;
          // Signal producer that queue has space
          if (queueResolve && queue.length < maxQueueSize) {
            queueResolve();
            queueResolve = null;
          }
          const promise = processBlock(block).then(() => {
            active.splice(active.indexOf(promise), 1);
          });
          active.push(promise);
        }

        // If queue empty but walk not done, wait for producer
        if (queue.length === 0 && !walkDone && active.length < concurrency) {
          await new Promise<void>(resolve => {
            consumerResolve = resolve;
          });
          continue;
        }

        // Wait for at least one task to complete
        if (active.length > 0) {
          await Promise.race(active);
        }
      }

      await Promise.all(active);
    };

    // Producer: walk tree and push to queue
    const runProducer = async () => {
      for await (const block of this.walkBlocks(id)) {
        if (options?.signal?.aborted) break;

        // Wait if queue is full
        while (queue.length >= maxQueueSize) {
          await new Promise<void>(resolve => {
            queueResolve = resolve;
          });
          if (options?.signal?.aborted) break;
        }

        queue.push(block);

        // Wake up consumer
        if (consumerResolve) {
          consumerResolve();
          consumerResolve = null;
        }
      }
      walkDone = true;
      // Wake consumer one last time
      if (consumerResolve) {
        consumerResolve();
        consumerResolve = null;
      }
    };

    // Run producer and consumer in parallel
    await Promise.all([runProducer(), runConsumer()]);

    return { cid: id, pushed, skipped, failed, bytes, errors, cancelled: options?.signal?.aborted ?? false };
  }

  // Edit operations

  /**
   * Add or update an entry in a directory
   * @param root - Root CID of the tree
   * @param path - Path to the directory containing the entry
   * @param name - Name of the entry
   * @param entry - CID of the entry content
   * @param size - Size of the content
   * @param type - Type of the entry (LinkType.Blob, LinkType.File, or LinkType.Dir)
   * @returns New root CID
   */
  async setEntry(
    root: CID,
    path: string[],
    name: string,
    entry: CID,
    size: number,
    type: LinkType = LinkType.Blob,
    meta?: Record<string, unknown>
  ): Promise<CID> {
    if (root.key) {
      const result = await editEncrypted.setEntryEncrypted(
        this.config,
        root.hash,
        root.key,
        path,
        name,
        entry.hash,
        size,
        entry.key,
        type,
        meta
      );
      return cid(result.hash, result.key);
    }
    const hash = await edit.setEntry(this.config, root.hash, path, name, entry, size, type, meta);
    return { hash };
  }

  /**
   * Remove an entry from a directory
   * @param root - Root CID of the tree
   * @param path - Path to the directory containing the entry
   * @param name - Name of the entry to remove
   * @returns New root CID
   */
  async removeEntry(root: CID, path: string[], name: string): Promise<CID> {
    if (root.key) {
      const result = await editEncrypted.removeEntryEncrypted(
        this.config,
        root.hash,
        root.key,
        path,
        name
      );
      return cid(result.hash, result.key);
    }
    const hash = await edit.removeEntry(this.config, root.hash, path, name);
    return { hash };
  }

  /**
   * Rename an entry in a directory
   * @param root - Root CID of the tree
   * @param path - Path to the directory containing the entry
   * @param oldName - Current name
   * @param newName - New name
   * @returns New root CID
   */
  async renameEntry(
    root: CID,
    path: string[],
    oldName: string,
    newName: string
  ): Promise<CID> {
    if (root.key) {
      const result = await editEncrypted.renameEntryEncrypted(
        this.config,
        root.hash,
        root.key,
        path,
        oldName,
        newName
      );
      return cid(result.hash, result.key);
    }
    const hash = await edit.renameEntry(this.config, root.hash, path, oldName, newName);
    return { hash };
  }

  /**
   * Move an entry to a different directory
   * @param root - Root CID of the tree
   * @param sourcePath - Path to the source directory
   * @param name - Name of the entry to move
   * @param targetPath - Path to the target directory
   * @returns New root CID
   */
  async moveEntry(
    root: CID,
    sourcePath: string[],
    name: string,
    targetPath: string[]
  ): Promise<CID> {
    if (root.key) {
      const result = await editEncrypted.moveEntryEncrypted(
        this.config,
        root.hash,
        root.key,
        sourcePath,
        name,
        targetPath
      );
      return cid(result.hash, result.key);
    }
    const hash = await edit.moveEntry(this.config, root.hash, sourcePath, name, targetPath);
    return { hash };
  }

  /**
   * Write data at a specific offset in a file
   * Only affected chunks are rewritten - efficient for small patches to large files.
   * Useful for updating file headers (e.g., WebM duration) without rewriting entire file.
   *
   * @param fileCid - CID of the file to modify
   * @param offset - Byte offset to write at
   * @param data - Data to write
   * @returns New file CID
   */
  async writeAt(fileCid: CID, offset: number, data: Uint8Array): Promise<CID> {
    if (fileCid.key) {
      const result = await writeAtOps.writeAtEncrypted(
        this.config,
        fileCid.hash,
        fileCid.key,
        offset,
        data
      );
      return cid(result.hash, result.key);
    }
    const result = await writeAtOps.writeAt(this.config, fileCid.hash, offset, data);
    return { hash: result.hash };
  }

  // Utility

  getStore(): Store {
    return this.store;
  }

  /**
   * Create a streaming file writer for incremental appends
   * Useful for writing large files chunk by chunk (e.g., video recording)
   * @param options.unencrypted - if true, create without encryption
   * @param options.chunker - custom chunker for variable chunk sizes (e.g., videoChunker for faster start)
   */
  createStream(options?: { unencrypted?: boolean; chunker?: streaming.Chunker }): StreamWriter {
    return new StreamWriter({
      store: this.store,
      chunkSize: this.chunkSize,
      chunker: options?.chunker,
      encryptionMode: this.encryptionMode,
      unencrypted: options?.unencrypted ?? false,
    });
  }
}
